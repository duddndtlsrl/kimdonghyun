#include <windows.h>

LRESULT CALLBACK WndProc(HWND, UINT, WPARAM, LPARAM);
HINSTANCE g_hInst;
char g_szClassName[256] = "Hello World!!";

int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpszCmdParam, int nCmdShow)
{
	HWND hWnd;
	MSG Message;
	WNDCLASS WndClass;
	g_hInst = hInstance;

	WndClass.cbClsExtra = 0;
	WndClass.cbWndExtra = 0;
	WndClass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	WndClass.hCursor = LoadCursor(NULL, IDC_ARROW);
	WndClass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	WndClass.hInstance = hInstance;
	WndClass.lpfnWndProc = WndProc;
	WndClass.lpszClassName = g_szClassName;
	WndClass.lpszMenuName = NULL;
	WndClass.style = CS_HREDRAW | CS_VREDRAW;
	RegisterClass(&WndClass);

	hWnd = CreateWindow(g_szClassName, g_szClassName, WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
		CW_USEDEFAULT, CW_USEDEFAULT, NULL, (HMENU)NULL, hInstance, NULL);
	ShowWindow(hWnd, nCmdShow);

	while (GetMessage(&Message, NULL, 0, 0))
	{
		TranslateMessage(&Message);
		DispatchMessage(&Message);
	}

	return (int)Message.wParam;
}

HWND cBox, autocBox;
BOOL bElipse = FALSE;

#define ID_R1 101
#define ID_R2 102
#define ID_R3 103
#define ID_R4 104
#define ID_R5 105

HWND rBlack, rRed, rBlue;
HWND rRect, rEllip;
HBRUSH MyBrush, OldBrush;

int graph = 0;
int color = 0;

LRESULT CALLBACK WndProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	
	switch (iMessage)
	{
	case WM_CREATE:
		//Push Button
		//CreateWindow(TEXT("button"), TEXT("Click Me"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 
		//	20, 20, 100, 25, hWnd, (HMENU)0, g_hInst, NULL);

		//CheckBox Button
		//���� üũ�ڽ�
		//cBox = CreateWindow(TEXT("button"), TEXT("Draw Ellipse?"), WS_CHILD | WS_VISIBLE 
		//	| BS_CHECKBOX, 20, 20, 160, 25, hWnd, (HMENU)0, g_hInst, NULL);

		////�ڵ� üũ�ڽ�
		//autocBox = CreateWindow(TEXT("button"), TEXT("Good bye Message?"), WS_CHILD | WS_VISIBLE 
		//	| BS_AUTOCHECKBOX, 20, 50, 160, 25, hWnd, (HMENU)1, g_hInst, NULL);

		//RadioButton
		//Group
		CreateWindow("button", "Graph", WS_CHILD | WS_VISIBLE |
			BS_GROUPBOX, 5, 5, 120, 110, hWnd, (HMENU)0, g_hInst, NULL);

		rRect = CreateWindow(TEXT("button"), TEXT("Rectangle"), WS_CHILD | WS_VISIBLE
				| BS_AUTORADIOBUTTON, 10, 20, 100, 30, hWnd, (HMENU)ID_R1, g_hInst, NULL);

		rEllip = CreateWindow(TEXT("button"), TEXT("Ellipse"), WS_CHILD | WS_VISIBLE
			| BS_AUTORADIOBUTTON, 10, 50, 100, 30, hWnd, (HMENU)ID_R2, g_hInst, NULL);

		//Group
		CreateWindow("button", "Color", WS_CHILD | WS_VISIBLE |
			BS_GROUPBOX, 145, 5, 120, 110, hWnd, (HMENU)1, g_hInst, NULL);

		rBlack = CreateWindow(TEXT("button"), TEXT("Black"), WS_CHILD | WS_VISIBLE
			| BS_AUTORADIOBUTTON, 150, 20, 100, 30, hWnd, (HMENU)ID_R3, g_hInst, NULL);

		rRed = CreateWindow(TEXT("button"), TEXT("Red"), WS_CHILD | WS_VISIBLE
			| BS_AUTORADIOBUTTON, 150, 50, 100, 30, hWnd, (HMENU)ID_R4, g_hInst, NULL);

		rBlue = CreateWindow(TEXT("button"), TEXT("Blue"), WS_CHILD | WS_VISIBLE
			| BS_AUTORADIOBUTTON, 150, 80, 100, 30, hWnd, (HMENU)ID_R5, g_hInst, NULL);

		//CheckRadioButton
		CheckRadioButton(hWnd, ID_R1, ID_R2, ID_R1);
		CheckRadioButton(hWnd, ID_R3, ID_R5, ID_R3);

		return 0;

	case WM_COMMAND:
		if (HIWORD(wParam) == BN_CLICKED) 
		{
			switch (LOWORD(wParam)) {
			case ID_R1:
				graph = 0;
				break;
			case ID_R2:
				graph = 1;
				break;
			case ID_R3:
				color = 0;
				break;
			case ID_R4:
				color = 1;
				break;
			case ID_R5:
				color = 2;
				break;
			}
		}

		//switch (LOWORD(wParam))
		//{
		//Push Button
		/*case 0:
			
			MessageBox(hWnd, TEXT("Button Clicked"), TEXT("Button"), MB_OK);
			
			break;*/

		//case 0:
		//	//���� : üũ���θ� �Ǵ��ϰ�  üũ�� �ٲ��ְ� ������ �ش�. 
		//	if (SendMessage(cBox, BM_GETCHECK, 0, 0) == BST_UNCHECKED)
		//	{
		//		//üũ�� ��ȯ
		//		SendMessage(cBox, BM_SETCHECK, BST_CHECKED, 0);
		//		
		//		//���ɼ���.
		//		bElipse = TRUE;
		//	}
		//	else
		//	{
		//		//üũ�� ��ȯ
		//		SendMessage(cBox, BM_SETCHECK, BST_UNCHECKED, 0);

		//		//���ɼ���.
		//		bElipse = FALSE;
		//	}
		//

		//	break;
		//}
		//���°� ����Ǿ ǥ��������ϱ� ������ �ٽ� �׷�����Ѵ�.
		InvalidateRect(hWnd, NULL, TRUE);

		return 0;

	case WM_PAINT:

		hdc = BeginPaint(hWnd, &ps);

		/*if (bElipse == TRUE)
			Ellipse(hdc, 200, 100, 400, 200);
		else
			Rectangle(hdc, 200, 100, 400, 200);*/

		switch (color) 
		{
		case 0:
			MyBrush = CreateSolidBrush(RGB(0, 0, 0));
			break;
		case 1:
			MyBrush = CreateSolidBrush(RGB(255, 0, 0));
			break;
		case 2:
			MyBrush = CreateSolidBrush(RGB(0, 0, 255));
			break;
		}
		OldBrush = (HBRUSH)SelectObject(hdc, MyBrush);
		
		switch (graph) 
		{
		case 0:
			Rectangle(hdc, 10, 200, 200, 300);
			break;
		case 1:
			Ellipse(hdc, 10, 200, 200, 300);
			break;
		}

		SelectObject(hdc, OldBrush);
		DeleteObject(MyBrush);

		EndPaint(hWnd, &ps);

		return 0;
	case WM_KEYDOWN:

		return 0;
	case WM_DESTROY:

		//�ڵ� : üũ�ڽ� Ŭ�� �������� Ư�� ������ ���� �� ���� üũ ���¸� �ľ��ؼ� ���.
		/*if (SendMessage(autocBox, BM_GETCHECK, 0, 0) == BST_CHECKED)
			MessageBox(hWnd, "Good bye", "Check", MB_OK);*/

		PostQuitMessage(0);
		return 0;
	}

	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}
